'use strict';

const request = require("request-promise-native");

process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;

const LINUX_WEB_APP = process.env.LINUX_WEB_APP || 'https://23.20.255.99/index.php?route=product/product&product_id=43';
const WIN_WEB_APP = process.env.WIN_WEB_APP || 'https://52.2.79.77/build-your-own-computer';

exports.handler = function(event, context) {

  generateLoad().then((result) => {
    console.log(result);
    return result;
  });

};

async function generateLoad() {

  let opencart = await request.get({
    url: LINUX_WEB_APP
  });

  let nopCommerce = await request.get({
    url: WIN_WEB_APP
  });

  return {
    opencart: opencart,
    nopCommerce: nopCommerce
  }

}
